using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("SafeExamBrowser.Configuration.UnitTests")]
[assembly: AssemblyDescription("Safe Exam Browser")]
[assembly: AssemblyCompany("ETH Zürich")]
[assembly: AssemblyProduct("SafeExamBrowser.Configuration.UnitTests")]
[assembly: AssemblyCopyright("Copyright © 2025 ETH Zürich, IT Services")]

[assembly: ComVisible(false)]

[assembly: Guid("9cdd03e7-ed65-409f-8c07-bd6f633a0170")]

// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("1.0.0.0")]
