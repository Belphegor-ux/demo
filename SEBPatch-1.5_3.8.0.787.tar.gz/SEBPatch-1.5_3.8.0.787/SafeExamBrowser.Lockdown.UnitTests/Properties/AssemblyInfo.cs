using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("SafeExamBrowser.Lockdown.UnitTests")]
[assembly: AssemblyDescription("Safe Exam Browser")]
[assembly: AssemblyCompany("ETH Zürich")]
[assembly: AssemblyProduct("SafeExamBrowser.Lockdown.UnitTests")]
[assembly: AssemblyCopyright("Copyright © 2025 ETH Zürich, IT Services")]

[assembly: ComVisible(false)]

[assembly: Guid("90378e33-3898-4a7c-be2d-2f3efcfc4bb5")]

// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("1.0.0.0")]
