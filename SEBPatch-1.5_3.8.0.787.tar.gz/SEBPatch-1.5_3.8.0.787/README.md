# Safe Exam Browser Patch
A patch to bypass Safe Exam Browser restrictions.

- Currently supported SEB version: 3.9.0.787

## How to use
Check out the [Wiki](https://github.com/school-cheating/SEBPatch/wiki)

## Mirrors
In case you can't download from the latest release, here is a list of mirrors (will be updated eventually):
* [Vichingo455's Software Repository](https://software-repository-website.vercel.app/Random%20Files/Projects/SEBPatch/)

## Credits
This project uses the same license as Safe Exam Browser, so it's completely legal.
However, it should be used with caution. I don't recommend cheating in exams as it could lead to educational consequences.
Safe Exam Browser is a product copyrighted by ETH Zurich and is modified here under the MPL License.
