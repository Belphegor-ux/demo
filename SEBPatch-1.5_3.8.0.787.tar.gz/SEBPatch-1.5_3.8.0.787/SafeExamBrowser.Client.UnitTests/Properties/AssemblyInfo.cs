using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("SafeExamBrowser.Client.UnitTests")]
[assembly: AssemblyDescription("Safe Exam Browser")]
[assembly: AssemblyCompany("ETH Zürich")]
[assembly: AssemblyProduct("SafeExamBrowser.Client.UnitTests")]
[assembly: AssemblyCopyright("Copyright © 2025 ETH Zürich, IT Services")]

[assembly: ComVisible(false)]

[assembly: Guid("15684416-fadf-4c51-85de-4f343bfab752")]

// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("1.0.0.0")]
